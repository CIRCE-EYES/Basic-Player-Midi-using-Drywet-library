﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Combo_output = New System.Windows.Forms.ComboBox()
        Me.Dir1 = New Microsoft.VisualBasic.Compatibility.VB6.DirListBox()
        Me.Drive1 = New Microsoft.VisualBasic.Compatibility.VB6.DriveListBox()
        Me.File1 = New Microsoft.VisualBasic.Compatibility.VB6.FileListBox()
        Me.btn3Panic = New System.Windows.Forms.Button()
        Me.label5 = New System.Windows.Forms.Label()
        Me.TrackBar1 = New System.Windows.Forms.TrackBar()
        Me.label2 = New System.Windows.Forms.Label()
        Me.TOTALTIME = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.progressBar1 = New System.Windows.Forms.ProgressBar()
        Me.btn1Stop = New System.Windows.Forms.Button()
        Me._Shape_5 = New System.Windows.Forms.Label()
        Me._Shape_6 = New System.Windows.Forms.Label()
        Me._Shape_7 = New System.Windows.Forms.Label()
        Me._Shape_8 = New System.Windows.Forms.Label()
        Me._Shape_1 = New System.Windows.Forms.Label()
        Me._Shape_2 = New System.Windows.Forms.Label()
        Me._Shape_3 = New System.Windows.Forms.Label()
        Me._Shape_4 = New System.Windows.Forms.Label()
        Me.label9 = New System.Windows.Forms.Label()
        Me.button2 = New System.Windows.Forms.Button()
        Me.trackBarBMP = New System.Windows.Forms.TrackBar()
        Me.Changed_Text_Tempo = New System.Windows.Forms.TextBox()
        Me.label7 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.radio_minus_6 = New System.Windows.Forms.RadioButton()
        Me.radio_minus_5 = New System.Windows.Forms.RadioButton()
        Me.radio_minus_4 = New System.Windows.Forms.RadioButton()
        Me.radio_minus_3 = New System.Windows.Forms.RadioButton()
        Me.radio_minus_2 = New System.Windows.Forms.RadioButton()
        Me.radio_more_6 = New System.Windows.Forms.RadioButton()
        Me.radio_more_5 = New System.Windows.Forms.RadioButton()
        Me.radio_more_4 = New System.Windows.Forms.RadioButton()
        Me.radio_more_3 = New System.Windows.Forms.RadioButton()
        Me.radio_more_2 = New System.Windows.Forms.RadioButton()
        Me.radio_0 = New System.Windows.Forms.RadioButton()
        Me.radio_more_1 = New System.Windows.Forms.RadioButton()
        Me.radio_minus_1 = New System.Windows.Forms.RadioButton()
        Me.label3 = New System.Windows.Forms.Label()
        Me.Actual_Text_Tempo = New System.Windows.Forms.TextBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.cbDoFileProgress = New System.Windows.Forms.CheckBox()
        Me.lblBeat = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trackBarBMP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.SlateGray
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(227, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 18)
        Me.Label4.TabIndex = 2083
        Me.Label4.Text = "MIDI  OUT"
        '
        'Combo_output
        '
        Me.Combo_output.BackColor = System.Drawing.Color.Black
        Me.Combo_output.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Combo_output.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Combo_output.ForeColor = System.Drawing.Color.White
        Me.Combo_output.FormattingEnabled = True
        Me.Combo_output.Location = New System.Drawing.Point(323, 10)
        Me.Combo_output.Name = "Combo_output"
        Me.Combo_output.Size = New System.Drawing.Size(181, 21)
        Me.Combo_output.TabIndex = 2084
        '
        'Dir1
        '
        Me.Dir1.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Dir1.ForeColor = System.Drawing.Color.White
        Me.Dir1.FormattingEnabled = True
        Me.Dir1.IntegralHeight = False
        Me.Dir1.Location = New System.Drawing.Point(12, 36)
        Me.Dir1.Name = "Dir1"
        Me.Dir1.Size = New System.Drawing.Size(202, 232)
        Me.Dir1.TabIndex = 2085
        '
        'Drive1
        '
        Me.Drive1.BackColor = System.Drawing.Color.White
        Me.Drive1.FormattingEnabled = True
        Me.Drive1.Location = New System.Drawing.Point(12, 6)
        Me.Drive1.Name = "Drive1"
        Me.Drive1.Size = New System.Drawing.Size(202, 21)
        Me.Drive1.TabIndex = 2086
        '
        'File1
        '
        Me.File1.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.File1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.File1.ForeColor = System.Drawing.Color.White
        Me.File1.FormattingEnabled = True
        Me.File1.Location = New System.Drawing.Point(12, 375)
        Me.File1.Name = "File1"
        Me.File1.Pattern = "*.mid"
        Me.File1.Size = New System.Drawing.Size(492, 340)
        Me.File1.TabIndex = 2087
        '
        'btn3Panic
        '
        Me.btn3Panic.BackColor = System.Drawing.Color.DarkRed
        Me.btn3Panic.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn3Panic.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3Panic.ForeColor = System.Drawing.Color.DarkGray
        Me.btn3Panic.Location = New System.Drawing.Point(138, 287)
        Me.btn3Panic.Name = "btn3Panic"
        Me.btn3Panic.Size = New System.Drawing.Size(76, 37)
        Me.btn3Panic.TabIndex = 2129
        Me.btn3Panic.Text = "panic"
        Me.btn3Panic.UseVisualStyleBackColor = False
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.label5.Location = New System.Drawing.Point(414, 47)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(27, 20)
        Me.label5.TabIndex = 2128
        Me.label5.Text = "---"
        '
        'TrackBar1
        '
        Me.TrackBar1.Location = New System.Drawing.Point(231, 93)
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Size = New System.Drawing.Size(273, 45)
        Me.TrackBar1.TabIndex = 2127
        Me.TrackBar1.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(226, 47)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(83, 20)
        Me.label2.TabIndex = 2126
        Me.label2.Text = "Duration:"
        '
        'TOTALTIME
        '
        Me.TOTALTIME.BackColor = System.Drawing.Color.SlateGray
        Me.TOTALTIME.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TOTALTIME.Cursor = System.Windows.Forms.Cursors.Default
        Me.TOTALTIME.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TOTALTIME.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TOTALTIME.Location = New System.Drawing.Point(339, 47)
        Me.TOTALTIME.Name = "TOTALTIME"
        Me.TOTALTIME.Size = New System.Drawing.Size(45, 19)
        Me.TOTALTIME.TabIndex = 2125
        Me.TOTALTIME.Text = "---"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(224, 141)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(203, 25)
        Me.label1.TabIndex = 2124
        Me.label1.Text = "Midi File Progress"
        '
        'progressBar1
        '
        Me.progressBar1.BackColor = System.Drawing.Color.DimGray
        Me.progressBar1.ForeColor = System.Drawing.Color.Lime
        Me.progressBar1.Location = New System.Drawing.Point(227, 170)
        Me.progressBar1.Maximum = 500
        Me.progressBar1.Name = "progressBar1"
        Me.progressBar1.Size = New System.Drawing.Size(277, 24)
        Me.progressBar1.TabIndex = 2123
        '
        'btn1Stop
        '
        Me.btn1Stop.BackColor = System.Drawing.Color.DarkRed
        Me.btn1Stop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn1Stop.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1Stop.ForeColor = System.Drawing.Color.DarkGray
        Me.btn1Stop.Location = New System.Drawing.Point(227, 210)
        Me.btn1Stop.Name = "btn1Stop"
        Me.btn1Stop.Size = New System.Drawing.Size(129, 58)
        Me.btn1Stop.TabIndex = 2122
        Me.btn1Stop.Text = "S  T  O  P"
        Me.btn1Stop.UseVisualStyleBackColor = False
        '
        '_Shape_5
        '
        Me._Shape_5.BackColor = System.Drawing.Color.White
        Me._Shape_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Shape_5.Location = New System.Drawing.Point(264, 343)
        Me._Shape_5.Name = "_Shape_5"
        Me._Shape_5.Size = New System.Drawing.Size(55, 16)
        Me._Shape_5.TabIndex = 2161
        '
        '_Shape_6
        '
        Me._Shape_6.BackColor = System.Drawing.Color.White
        Me._Shape_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Shape_6.Location = New System.Drawing.Point(327, 343)
        Me._Shape_6.Name = "_Shape_6"
        Me._Shape_6.Size = New System.Drawing.Size(55, 16)
        Me._Shape_6.TabIndex = 2162
        '
        '_Shape_7
        '
        Me._Shape_7.BackColor = System.Drawing.Color.White
        Me._Shape_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Shape_7.Location = New System.Drawing.Point(390, 343)
        Me._Shape_7.Name = "_Shape_7"
        Me._Shape_7.Size = New System.Drawing.Size(55, 16)
        Me._Shape_7.TabIndex = 2163
        '
        '_Shape_8
        '
        Me._Shape_8.BackColor = System.Drawing.Color.White
        Me._Shape_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Shape_8.Location = New System.Drawing.Point(453, 343)
        Me._Shape_8.Name = "_Shape_8"
        Me._Shape_8.Size = New System.Drawing.Size(55, 16)
        Me._Shape_8.TabIndex = 2164
        '
        '_Shape_1
        '
        Me._Shape_1.BackColor = System.Drawing.Color.White
        Me._Shape_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Shape_1.Location = New System.Drawing.Point(12, 343)
        Me._Shape_1.Name = "_Shape_1"
        Me._Shape_1.Size = New System.Drawing.Size(55, 16)
        Me._Shape_1.TabIndex = 2156
        '
        '_Shape_2
        '
        Me._Shape_2.BackColor = System.Drawing.Color.White
        Me._Shape_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Shape_2.Location = New System.Drawing.Point(75, 343)
        Me._Shape_2.Name = "_Shape_2"
        Me._Shape_2.Size = New System.Drawing.Size(55, 16)
        Me._Shape_2.TabIndex = 2157
        '
        '_Shape_3
        '
        Me._Shape_3.BackColor = System.Drawing.Color.White
        Me._Shape_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Shape_3.Location = New System.Drawing.Point(138, 343)
        Me._Shape_3.Name = "_Shape_3"
        Me._Shape_3.Size = New System.Drawing.Size(55, 16)
        Me._Shape_3.TabIndex = 2158
        '
        '_Shape_4
        '
        Me._Shape_4.BackColor = System.Drawing.Color.White
        Me._Shape_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me._Shape_4.Location = New System.Drawing.Point(201, 343)
        Me._Shape_4.Name = "_Shape_4"
        Me._Shape_4.Size = New System.Drawing.Size(55, 16)
        Me._Shape_4.TabIndex = 2159
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label9.Location = New System.Drawing.Point(894, 148)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(31, 20)
        Me.label9.TabIndex = 2154
        Me.label9.Text = "-->"
        '
        'button2
        '
        Me.button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button2.ForeColor = System.Drawing.Color.Black
        Me.button2.Location = New System.Drawing.Point(789, 145)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(92, 28)
        Me.button2.TabIndex = 2152
        Me.button2.Text = "Sync"
        Me.button2.UseVisualStyleBackColor = False
        '
        'trackBarBMP
        '
        Me.trackBarBMP.BackColor = System.Drawing.Color.SlateGray
        Me.trackBarBMP.Location = New System.Drawing.Point(565, 202)
        Me.trackBarBMP.Maximum = 800
        Me.trackBarBMP.Minimum = 40
        Me.trackBarBMP.Name = "trackBarBMP"
        Me.trackBarBMP.Size = New System.Drawing.Size(544, 45)
        Me.trackBarBMP.TabIndex = 2151
        Me.trackBarBMP.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.trackBarBMP.Value = 120
        '
        'Changed_Text_Tempo
        '
        Me.Changed_Text_Tempo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Changed_Text_Tempo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Changed_Text_Tempo.Location = New System.Drawing.Point(946, 148)
        Me.Changed_Text_Tempo.Name = "Changed_Text_Tempo"
        Me.Changed_Text_Tempo.Size = New System.Drawing.Size(90, 26)
        Me.Changed_Text_Tempo.TabIndex = 2150
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label7.Location = New System.Drawing.Point(938, 126)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(106, 16)
        Me.label7.TabIndex = 2149
        Me.label7.Text = "Changed BPM"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label6.Location = New System.Drawing.Point(701, 21)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(269, 31)
        Me.label6.TabIndex = 2148
        Me.label6.Text = "TRANSPOSE  MIDI"
        '
        'radio_minus_6
        '
        Me.radio_minus_6.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_minus_6.AutoSize = True
        Me.radio_minus_6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radio_minus_6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_minus_6.Location = New System.Drawing.Point(565, 65)
        Me.radio_minus_6.Name = "radio_minus_6"
        Me.radio_minus_6.Size = New System.Drawing.Size(35, 30)
        Me.radio_minus_6.TabIndex = 2147
        Me.radio_minus_6.TabStop = True
        Me.radio_minus_6.Text = "-6"
        Me.radio_minus_6.UseVisualStyleBackColor = True
        '
        'radio_minus_5
        '
        Me.radio_minus_5.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_minus_5.AutoSize = True
        Me.radio_minus_5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radio_minus_5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_minus_5.Location = New System.Drawing.Point(606, 65)
        Me.radio_minus_5.Name = "radio_minus_5"
        Me.radio_minus_5.Size = New System.Drawing.Size(35, 30)
        Me.radio_minus_5.TabIndex = 2146
        Me.radio_minus_5.TabStop = True
        Me.radio_minus_5.Text = "-5"
        Me.radio_minus_5.UseVisualStyleBackColor = True
        '
        'radio_minus_4
        '
        Me.radio_minus_4.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_minus_4.AutoSize = True
        Me.radio_minus_4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radio_minus_4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_minus_4.Location = New System.Drawing.Point(647, 65)
        Me.radio_minus_4.Name = "radio_minus_4"
        Me.radio_minus_4.Size = New System.Drawing.Size(35, 30)
        Me.radio_minus_4.TabIndex = 2145
        Me.radio_minus_4.TabStop = True
        Me.radio_minus_4.Text = "-4"
        Me.radio_minus_4.UseVisualStyleBackColor = True
        '
        'radio_minus_3
        '
        Me.radio_minus_3.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_minus_3.AutoSize = True
        Me.radio_minus_3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radio_minus_3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_minus_3.Location = New System.Drawing.Point(688, 65)
        Me.radio_minus_3.Name = "radio_minus_3"
        Me.radio_minus_3.Size = New System.Drawing.Size(35, 30)
        Me.radio_minus_3.TabIndex = 2144
        Me.radio_minus_3.TabStop = True
        Me.radio_minus_3.Text = "-3"
        Me.radio_minus_3.UseVisualStyleBackColor = True
        '
        'radio_minus_2
        '
        Me.radio_minus_2.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_minus_2.AutoSize = True
        Me.radio_minus_2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radio_minus_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_minus_2.Location = New System.Drawing.Point(729, 65)
        Me.radio_minus_2.Name = "radio_minus_2"
        Me.radio_minus_2.Size = New System.Drawing.Size(35, 30)
        Me.radio_minus_2.TabIndex = 2143
        Me.radio_minus_2.TabStop = True
        Me.radio_minus_2.Text = "-2"
        Me.radio_minus_2.UseVisualStyleBackColor = True
        '
        'radio_more_6
        '
        Me.radio_more_6.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_more_6.AutoSize = True
        Me.radio_more_6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_more_6.Location = New System.Drawing.Point(1072, 65)
        Me.radio_more_6.Name = "radio_more_6"
        Me.radio_more_6.Size = New System.Drawing.Size(39, 30)
        Me.radio_more_6.TabIndex = 2142
        Me.radio_more_6.TabStop = True
        Me.radio_more_6.Text = "+6"
        Me.radio_more_6.UseVisualStyleBackColor = True
        '
        'radio_more_5
        '
        Me.radio_more_5.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_more_5.AutoSize = True
        Me.radio_more_5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_more_5.Location = New System.Drawing.Point(1027, 65)
        Me.radio_more_5.Name = "radio_more_5"
        Me.radio_more_5.Size = New System.Drawing.Size(39, 30)
        Me.radio_more_5.TabIndex = 2141
        Me.radio_more_5.TabStop = True
        Me.radio_more_5.Text = "+5"
        Me.radio_more_5.UseVisualStyleBackColor = True
        '
        'radio_more_4
        '
        Me.radio_more_4.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_more_4.AutoSize = True
        Me.radio_more_4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_more_4.Location = New System.Drawing.Point(982, 65)
        Me.radio_more_4.Name = "radio_more_4"
        Me.radio_more_4.Size = New System.Drawing.Size(39, 30)
        Me.radio_more_4.TabIndex = 2140
        Me.radio_more_4.TabStop = True
        Me.radio_more_4.Text = "+4"
        Me.radio_more_4.UseVisualStyleBackColor = True
        '
        'radio_more_3
        '
        Me.radio_more_3.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_more_3.AutoSize = True
        Me.radio_more_3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_more_3.Location = New System.Drawing.Point(937, 65)
        Me.radio_more_3.Name = "radio_more_3"
        Me.radio_more_3.Size = New System.Drawing.Size(39, 30)
        Me.radio_more_3.TabIndex = 2139
        Me.radio_more_3.TabStop = True
        Me.radio_more_3.Text = "+3"
        Me.radio_more_3.UseVisualStyleBackColor = True
        '
        'radio_more_2
        '
        Me.radio_more_2.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_more_2.AutoSize = True
        Me.radio_more_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_more_2.Location = New System.Drawing.Point(892, 65)
        Me.radio_more_2.Name = "radio_more_2"
        Me.radio_more_2.Size = New System.Drawing.Size(39, 30)
        Me.radio_more_2.TabIndex = 2138
        Me.radio_more_2.TabStop = True
        Me.radio_more_2.Text = "+2"
        Me.radio_more_2.UseVisualStyleBackColor = True
        '
        'radio_0
        '
        Me.radio_0.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_0.AutoSize = True
        Me.radio_0.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_0.Location = New System.Drawing.Point(812, 65)
        Me.radio_0.Name = "radio_0"
        Me.radio_0.Size = New System.Drawing.Size(29, 30)
        Me.radio_0.TabIndex = 2137
        Me.radio_0.TabStop = True
        Me.radio_0.Text = "0"
        Me.radio_0.UseVisualStyleBackColor = True
        '
        'radio_more_1
        '
        Me.radio_more_1.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_more_1.AutoSize = True
        Me.radio_more_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_more_1.Location = New System.Drawing.Point(847, 65)
        Me.radio_more_1.Name = "radio_more_1"
        Me.radio_more_1.Size = New System.Drawing.Size(39, 30)
        Me.radio_more_1.TabIndex = 2136
        Me.radio_more_1.TabStop = True
        Me.radio_more_1.Text = "+1"
        Me.radio_more_1.UseVisualStyleBackColor = True
        '
        'radio_minus_1
        '
        Me.radio_minus_1.Appearance = System.Windows.Forms.Appearance.Button
        Me.radio_minus_1.AutoSize = True
        Me.radio_minus_1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radio_minus_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radio_minus_1.Location = New System.Drawing.Point(770, 65)
        Me.radio_minus_1.Name = "radio_minus_1"
        Me.radio_minus_1.Size = New System.Drawing.Size(35, 30)
        Me.radio_minus_1.TabIndex = 2135
        Me.radio_minus_1.TabStop = True
        Me.radio_minus_1.Text = "-1"
        Me.radio_minus_1.UseVisualStyleBackColor = True
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.BackColor = System.Drawing.Color.SlateGray
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.ForeColor = System.Drawing.Color.Black
        Me.label3.Location = New System.Drawing.Point(641, 128)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(93, 16)
        Me.label3.TabIndex = 2134
        Me.label3.Text = "Source BPM"
        '
        'Actual_Text_Tempo
        '
        Me.Actual_Text_Tempo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Actual_Text_Tempo.Location = New System.Drawing.Point(644, 147)
        Me.Actual_Text_Tempo.Name = "Actual_Text_Tempo"
        Me.Actual_Text_Tempo.Size = New System.Drawing.Size(90, 26)
        Me.Actual_Text_Tempo.TabIndex = 2133
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label8.Location = New System.Drawing.Point(742, 148)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(31, 20)
        Me.label8.TabIndex = 2153
        Me.label8.Text = "-->"
        '
        'cbDoFileProgress
        '
        Me.cbDoFileProgress.Appearance = System.Windows.Forms.Appearance.Button
        Me.cbDoFileProgress.BackColor = System.Drawing.Color.Goldenrod
        Me.cbDoFileProgress.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbDoFileProgress.Location = New System.Drawing.Point(362, 210)
        Me.cbDoFileProgress.Name = "cbDoFileProgress"
        Me.cbDoFileProgress.Size = New System.Drawing.Size(142, 58)
        Me.cbDoFileProgress.TabIndex = 2165
        Me.cbDoFileProgress.Text = "Play All"
        Me.cbDoFileProgress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.cbDoFileProgress.UseVisualStyleBackColor = False
        '
        'lblBeat
        '
        Me.lblBeat.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblBeat.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblBeat.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBeat.ForeColor = System.Drawing.Color.Lime
        Me.lblBeat.Location = New System.Drawing.Point(77, 288)
        Me.lblBeat.Name = "lblBeat"
        Me.lblBeat.Size = New System.Drawing.Size(39, 38)
        Me.lblBeat.TabIndex = 2166
        Me.lblBeat.Text = "X"
        Me.lblBeat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(14, 294)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 25)
        Me.Label10.TabIndex = 2167
        Me.Label10.Text = "Beat :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label11.Location = New System.Drawing.Point(390, 47)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(14, 20)
        Me.Label11.TabIndex = 2168
        Me.Label11.Text = "/"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SlateGray
        Me.ClientSize = New System.Drawing.Size(1140, 722)
        Me.Controls.Add(Me.lblBeat)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.cbDoFileProgress)
        Me.Controls.Add(Me._Shape_5)
        Me.Controls.Add(Me._Shape_6)
        Me.Controls.Add(Me._Shape_7)
        Me.Controls.Add(Me._Shape_8)
        Me.Controls.Add(Me._Shape_1)
        Me.Controls.Add(Me._Shape_2)
        Me.Controls.Add(Me._Shape_3)
        Me.Controls.Add(Me._Shape_4)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.trackBarBMP)
        Me.Controls.Add(Me.Changed_Text_Tempo)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.radio_minus_6)
        Me.Controls.Add(Me.radio_minus_5)
        Me.Controls.Add(Me.radio_minus_4)
        Me.Controls.Add(Me.radio_minus_3)
        Me.Controls.Add(Me.radio_minus_2)
        Me.Controls.Add(Me.radio_more_6)
        Me.Controls.Add(Me.radio_more_5)
        Me.Controls.Add(Me.radio_more_4)
        Me.Controls.Add(Me.radio_more_3)
        Me.Controls.Add(Me.radio_more_2)
        Me.Controls.Add(Me.radio_0)
        Me.Controls.Add(Me.radio_more_1)
        Me.Controls.Add(Me.radio_minus_1)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.Actual_Text_Tempo)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.btn3Panic)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.TrackBar1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.TOTALTIME)
        Me.Controls.Add(Me.progressBar1)
        Me.Controls.Add(Me.btn1Stop)
        Me.Controls.Add(Me.File1)
        Me.Controls.Add(Me.Drive1)
        Me.Controls.Add(Me.Dir1)
        Me.Controls.Add(Me.Combo_output)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.label1)
        Me.Name = "Form1"
        Me.Text = "New Simply Player from MAXIM  DRYWETMIDI LIBRARY"
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trackBarBMP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label4 As Label
    Friend WithEvents Combo_output As ComboBox
    Friend WithEvents Dir1 As Compatibility.VB6.DirListBox
    Friend WithEvents Drive1 As Compatibility.VB6.DriveListBox
    Friend WithEvents File1 As Compatibility.VB6.FileListBox
    Friend WithEvents btn3Panic As Button
    Private WithEvents label5 As Label
    Private WithEvents TrackBar1 As TrackBar
    Private WithEvents label2 As Label
    Friend WithEvents TOTALTIME As TextBox
    Private WithEvents label1 As Label
    Private WithEvents progressBar1 As ProgressBar
    Friend WithEvents btn1Stop As Button
    Public WithEvents _Shape_5 As Label
    Public WithEvents _Shape_6 As Label
    Public WithEvents _Shape_7 As Label
    Public WithEvents _Shape_8 As Label
    Public WithEvents _Shape_1 As Label
    Public WithEvents _Shape_2 As Label
    Public WithEvents _Shape_3 As Label
    Public WithEvents _Shape_4 As Label
    Private WithEvents label9 As Label
    Friend WithEvents button2 As Button
    Friend WithEvents trackBarBMP As TrackBar
    Friend WithEvents Changed_Text_Tempo As TextBox
    Private WithEvents label7 As Label
    Private WithEvents label6 As Label
    Private WithEvents radio_minus_6 As RadioButton
    Private WithEvents radio_minus_5 As RadioButton
    Private WithEvents radio_minus_4 As RadioButton
    Private WithEvents radio_minus_3 As RadioButton
    Private WithEvents radio_minus_2 As RadioButton
    Private WithEvents radio_more_6 As RadioButton
    Private WithEvents radio_more_5 As RadioButton
    Private WithEvents radio_more_4 As RadioButton
    Private WithEvents radio_more_3 As RadioButton
    Private WithEvents radio_more_2 As RadioButton
    Private WithEvents radio_0 As RadioButton
    Private WithEvents radio_more_1 As RadioButton
    Private WithEvents radio_minus_1 As RadioButton
    Private WithEvents label3 As Label
    Friend WithEvents Actual_Text_Tempo As TextBox
    Private WithEvents label8 As Label
    Friend WithEvents cbDoFileProgress As CheckBox
    Friend WithEvents lblBeat As Label
    Friend WithEvents Label10 As Label
    Private WithEvents Label11 As Label
End Class
