﻿Imports Melanchall.DryWetMidi.Devices
Imports Melanchall.DryWetMidi.Common
Imports Melanchall.DryWetMidi.Interaction
Imports Melanchall.DryWetMidi.Core

Public Class Form1

	Public _outputDevice As OutputDevice
	Public _playback As Playback
	Dim a As Short

	Private Do_FileProgress As Boolean      ' False = play in Loop mode, True = when File was played jump to next file


	Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		For Each portname_out As OutputDevice In OutputDevice.GetAll()

			Combo_output.Items.Add(portname_out)

		Next portname_out

		Combo_output.SelectedIndex = 0

		_outputDevice = DirectCast(Combo_output.SelectedItem, OutputDevice)

		File1.Path = Dir1.Path
		File1.Refresh()
		cbDoFileProgress.Checked = True
	End Sub

	Private Sub Dir1_Change(sender As Object, e As EventArgs) Handles Dir1.Change
		File1.Path = Dir1.Path
	End Sub

	Private Sub Drive1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Drive1.SelectedIndexChanged
		Dir1.Path = Drive1.Drive
	End Sub

	Private Sub btn3Panic_Click(sender As Object, e As EventArgs) Handles btn3Panic.Click
		_outputDevice.TurnAllNotesOff() ' Has a bit delay....
	End Sub

	Private Sub btn1Stop_Click(sender As Object, e As EventArgs) Handles btn1Stop.Click
		Dim volume As Integer
		volume = 0
		progressBar1.Value = 0
		TrackBar1.Value = 0
		ShapeProgress(0)

		If _playback Is Nothing Then Return

		PlaybackCurrentTimeWatcher.Instance.RemovePlayback(_playback)
		RemoveHandler PlaybackCurrentTimeWatcher.Instance.CurrentTimeChanged, AddressOf OnPlaybackCurrentTimeChanged
		PlaybackCurrentTimeWatcher.Instance.Stop()

		_playback.InterruptNotesOnStop = True
		_outputDevice.SendEvent(New ControlChangeEvent(CType(ControlName.DamperPedal, SevenBitNumber), CType(0, SevenBitNumber)))
		_playback.Stop()
	End Sub

	Private Sub OnPlaybackCurrentTimeChanged(sender As Object, e As PlaybackCurrentTimeChangedEventArgs)
		Dim time = CInt(CType(e.Times.First().Time, MidiTimeSpan).TimeSpan)
		progressBar1.Invoke(CType(Sub() progressBar1.Value = time, MethodInvoker))
		TrackBar1.Invoke(CType(Sub() TrackBar1.Value = time, MethodInvoker))
		label5.Invoke(CType(Sub() label5.Text = TimeConverter.ConvertTo(Of MetricTimeSpan)(time, _playback.TempoMap).ToString(), MethodInvoker))


		'--- current Beat calculation ---

		Dim td As New TicksPerQuarterNoteTimeDivision
		td = CType(_playback.TempoMap.TimeDivision, TicksPerQuarterNoteTimeDivision)
		Dim tpqn As Integer = td.TicksPerQuarterNote

		Dim beat As Integer = (time \ tpqn) + 1
		lblBeat.Invoke(CType(Sub() lblBeat.Text = CStr(beat), MethodInvoker))

		'shape progress
		Me.Invoke(New ShapeProgress_Delegate(AddressOf ShapeProgress), beat)
		'---

	End Sub

	Private Delegate Sub ShapeProgress_Delegate(beat As Integer)

	Private CurrentShape As Integer

	Private Sub ShapeProgress(beat As Integer)

		'--- set all shapes white
		If beat = 0 Then
			If CurrentShape <> 0 Then
				ShapeOff(CurrentShape)
				CurrentShape = 0
			End If
			Exit Sub
		End If

		'--- set shape to red
		If beat <> CurrentShape Then
			ShapeOff(CurrentShape)
			ShapeOn(beat)
			CurrentShape = beat
		End If

	End Sub

	Private Sub ShapeOn(number As Integer)
		Select Case number
			Case 1
				_Shape_1.BackColor = Color.Red
			Case 2
				_Shape_2.BackColor = Color.Red
			Case 3
				_Shape_3.BackColor = Color.Red
			Case 4
				_Shape_4.BackColor = Color.Red
			Case 5
				_Shape_5.BackColor = Color.Red
			Case 6
				_Shape_6.BackColor = Color.Red
			Case 7
				_Shape_7.BackColor = Color.Red
			Case 8
				_Shape_8.BackColor = Color.Red
		End Select
	End Sub

	Private Sub ShapeOff(number As Integer)
		Select Case number
			Case 1
				_Shape_1.BackColor = Color.White
			Case 2
				_Shape_2.BackColor = Color.White
			Case 3
				_Shape_3.BackColor = Color.White
			Case 4
				_Shape_4.BackColor = Color.White
			Case 5
				_Shape_5.BackColor = Color.White
			Case 6
				_Shape_6.BackColor = Color.White
			Case 7
				_Shape_7.BackColor = Color.White
			Case 8
				_Shape_8.BackColor = Color.White
		End Select
	End Sub


	Private Sub Combo_output_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combo_output.SelectedIndexChanged
		_outputDevice = DirectCast(Combo_output.SelectedItem, OutputDevice)
	End Sub

	Private Sub TrackBar1_ValueChanged(sender As Object, e As EventArgs) Handles TrackBar1.ValueChanged
		If _playback IsNot Nothing Then _playback.MoveToTime(New MidiTimeSpan(TrackBar1.Value))
	End Sub

	Private Sub File1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles File1.SelectedIndexChanged
		btn1Stop.PerformClick()

		Dim FN As String = Nothing
		If File1.Path.Substring(Len(File1.Path) - 1) = "\" Then

			FN = File1.Path & File1.FileName

		Else

			FN = File1.Path & "\" & File1.FileName

			If File1.SelectedItem Is Nothing Then Return

			Dim valuebpm = trackBarBMP.Value
			Dim midiFile = Melanchall.DryWetMidi.Core.MidiFile.Read(FN)
			Dim tempoMap = midiFile.GetTempoMap()
			Dim originalBpm = tempoMap.GetTempoAtTime(New MidiTimeSpan(0)).BeatsPerMinute
			Actual_Text_Tempo.Text = CStr(originalBpm)
			Dim newSpeed = CDbl(valuebpm) / originalBpm

			Dim midiFileDuration As TimeSpan = midiFile.GetDuration(Of MetricTimeSpan)()
			Dim TotalTime_Renamed = midiFileDuration.ToString("m\:ss") ' Usefullllllll !!!!!!


			If radio_minus_1.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 1
				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) - transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)

			End If
			If radio_minus_2.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 2

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) - transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If
			If radio_minus_3.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 3
				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) - transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If
			If radio_minus_4.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 4

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) - transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If
			If radio_minus_5.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 5

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) - transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If
			If radio_minus_6.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 6

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) - transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If

			If radio_more_1.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 1

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) + transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If
			If radio_more_2.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 2

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) + transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If
			If radio_more_3.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 3

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) + transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If
			If radio_more_4.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 4

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) + transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If
			If radio_more_5.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 5

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) + transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If
			If radio_more_6.Checked = True Then

				btn1Stop.PerformClick()
				Dim transposeBy = 6

				midiFile.ProcessNotes(Sub(n) n.NoteNumber = CType(CType(n.NoteNumber, Integer) + transposeBy, SevenBitNumber), Function(n) CType(n.Channel, Integer) <> 9)  'All Channels less 9 (drums)
			End If

			TOTALTIME.Text = TotalTime_Renamed

			If _playback IsNot Nothing AndAlso
				_playback.IsRunning Then

				PlaybackCurrentTimeWatcher.Instance.RemovePlayback(_playback)
				RemoveHandler PlaybackCurrentTimeWatcher.Instance.CurrentTimeChanged, AddressOf OnPlaybackCurrentTimeChanged
				RemoveHandler _playback.RepeatStarted, AddressOf PlaybackRepeatStarted
				PlaybackCurrentTimeWatcher.Instance.Stop()

				_playback.Stop()
				_playback.Dispose()
				progressBar1.Value = 0
				TrackBar1.Value = 0

			End If

			_playback = midiFile.GetPlayback(_outputDevice)
			_playback.Speed = newSpeed
			_playback.Loop = (True)

			Dim duration = _playback.GetDuration(Of MidiTimeSpan)().TimeSpan

			progressBar1.Maximum = CInt(duration)
			TrackBar1.Maximum = CInt(duration)

			PlaybackCurrentTimeWatcher.Instance.AddPlayback(_playback, TimeSpanType.Midi)
			AddHandler PlaybackCurrentTimeWatcher.Instance.CurrentTimeChanged, AddressOf OnPlaybackCurrentTimeChanged
			PlaybackCurrentTimeWatcher.Instance.Start()

			'---
			AddHandler _playback.RepeatStarted, AddressOf PlaybackRepeatStarted
			'---

			_playback.Start()

		End If
	End Sub

	Private Sub PlaybackRepeatStarted(sender As Object, e As EventArgs)
		If Do_FileProgress = True Then
			File1.Invoke(New FileProgress_Delegate(AddressOf Threadsave_FileProgress))
		End If
	End Sub

	Private Delegate Sub FileProgress_Delegate()

	Private Sub Threadsave_FileProgress()
		File1.SetSelected((File1.SelectedIndex + 1) Mod File1.Items.Count, True)
	End Sub

	Private Sub radio_minus_1_CheckedChanged(sender As Object, e As EventArgs) Handles radio_minus_1.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_minus_2_CheckedChanged(sender As Object, e As EventArgs) Handles radio_minus_2.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_minus_3_CheckedChanged(sender As Object, e As EventArgs) Handles radio_minus_3.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_minus_4_CheckedChanged(sender As Object, e As EventArgs) Handles radio_minus_4.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_minus_5_CheckedChanged(sender As Object, e As EventArgs) Handles radio_minus_5.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_minus_6_CheckedChanged(sender As Object, e As EventArgs) Handles radio_minus_6.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub

	'=============================================================================

	Private Sub radio_more_1_CheckedChanged(sender As Object, e As EventArgs) Handles radio_more_1.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_more_2_CheckedChanged(sender As Object, e As EventArgs) Handles radio_more_2.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_more_3_CheckedChanged(sender As Object, e As EventArgs) Handles radio_more_3.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_more_4_CheckedChanged(sender As Object, e As EventArgs) Handles radio_more_4.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_more_5_CheckedChanged(sender As Object, e As EventArgs) Handles radio_more_5.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub
	Private Sub radio_more_6_CheckedChanged(sender As Object, e As EventArgs) Handles radio_more_6.CheckedChanged
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub

	Private Sub trackBarBMP_MouseUp(sender As Object, e As MouseEventArgs) Handles trackBarBMP.MouseUp
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub

	Private Sub trackBarBMP_ValueChanged(sender As Object, e As EventArgs) Handles trackBarBMP.ValueChanged
		Changed_Text_Tempo.Text = CStr(trackBarBMP.Value)

		'--- not used, but Formula seems to be ok
		Dim tempo As Single
		tempo = CSng(Val(Changed_Text_Tempo.Text))
		Dim interval As Integer = CInt(60 * (1000 / tempo)) '  Timer for squares (in first version)
	End Sub

	Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
		If Actual_Text_Tempo.Text = "" Then
			MessageBox.Show("First selec Midifile to Sync BPM")
			Return
		End If

		Dim coco = CDbl(Actual_Text_Tempo.Text)
		trackBarBMP.Value = CInt(CStr(coco))

		'	Changed_Text_Tempo.Text = Actual_Text_Tempo.Text.ToString();
		trackBarBMP.Update()
		trackBarBMP.Select()
		btn1Stop.PerformClick()
		File1_SelectedIndexChanged(sender, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
	End Sub

	Private Sub cbDoFileProgress_CheckedChanged(sender As Object, e As EventArgs) Handles cbDoFileProgress.CheckedChanged
		If cbDoFileProgress.Checked Then
			Do_FileProgress = True
			cbDoFileProgress.BackColor = Color.Goldenrod
			cbDoFileProgress.Text = "Play All"
		Else
			Do_FileProgress = False
			cbDoFileProgress.BackColor = Color.Aquamarine
			cbDoFileProgress.Text = "LOOP"
		End If
	End Sub
End Class
